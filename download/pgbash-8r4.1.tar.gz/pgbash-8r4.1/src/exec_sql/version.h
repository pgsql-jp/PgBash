/*----------------------------------------------------------------
 * version.h
 *
 *-----------------------------------------------------------------
 */
#ifndef PGBASH_VERSION_HEADER
#define PGBASH_VERSION_HEADER

#define PGBASH_PATCH_VERSION   "Patch Ver.8 r4.1"

#endif
